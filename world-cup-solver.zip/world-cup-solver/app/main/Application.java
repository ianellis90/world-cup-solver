package main;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Application {
    public static void main(String args[]){
        try {
            FileInputStream excelFile = new FileInputStream(new File("/Users/ianellis/Downloads/play-java-jpa-example-2.5.x/conf/Ian_Test_World_Cup_2018.xlsx"));
            XSSFWorkbook workbook = new XSSFWorkbook(excelFile);
            Sheet data = workbook.getSheetAt(0);
            Sheet results = workbook.getSheetAt(1);


            Iterator<Row> iterator = data.iterator();
            Integer rowNum = 0;

            while(iterator.hasNext()) {
                Row row = iterator.next();

                if(rowNum == 0) {
                    Row newRow = results.createRow(rowNum);
                    Cell resultRef = newRow.createCell(0);
                    Cell resultName = newRow.createCell(1);
                    Cell totalPoints = newRow.createCell(2);

                    resultRef.setCellValue("Ref");
                    resultName.setCellValue("Name");
                    totalPoints.setCellValue("Total Points");

                    rowNum++;
                }
                else{
                    Integer points = 0;
                    String ref = row.getCell(0).getStringCellValue().toUpperCase();
                    String name = row.getCell(1).getStringCellValue().toUpperCase();
                    String winnerA = row.getCell(2).getStringCellValue().toUpperCase();
                    String runnerUpB = row.getCell(3).getStringCellValue().toUpperCase();
                    String winnerC = row.getCell(4).getStringCellValue().toUpperCase();
                    String runnerUpD = row.getCell(5).getStringCellValue().toUpperCase();
                    String winnerE = row.getCell(6).getStringCellValue().toUpperCase();
                    String runnerUpF = row.getCell(7).getStringCellValue().toUpperCase();
                    String winnerG = row.getCell(8).getStringCellValue().toUpperCase();
                    String runnerUpH = row.getCell(9).getStringCellValue().toUpperCase();
                    String winnerB = row.getCell(10).getStringCellValue().toUpperCase();
                    String runnerUpA = row.getCell(11).getStringCellValue().toUpperCase();
                    String winnerD = row.getCell(12).getStringCellValue().toUpperCase();
                    String runnerUpC = row.getCell(13).getStringCellValue().toUpperCase();
                    String winnerF = row.getCell(14).getStringCellValue().toUpperCase();
                    String runnerUpE = row.getCell(15).getStringCellValue().toUpperCase();
                    String winnerH = row.getCell(16).getStringCellValue().toUpperCase();
                    String runnerUpG = row.getCell(17).getStringCellValue().toUpperCase();
                    String quarterFinal1 = row.getCell(18).getStringCellValue().toUpperCase();
                    String quarterFinal2 = row.getCell(19).getStringCellValue().toUpperCase();
                    String quarterFinal3 = row.getCell(20).getStringCellValue().toUpperCase();
                    String quarterFinal4 = row.getCell(21).getStringCellValue().toUpperCase();
                    String quarterFinal5 = row.getCell(22).getStringCellValue().toUpperCase();
                    String quarterFinal6 = row.getCell(23).getStringCellValue().toUpperCase();
                    String quarterFinal7 = row.getCell(24).getStringCellValue().toUpperCase();
                    String quarterFinal8 = row.getCell(25).getStringCellValue().toUpperCase();
                    String semiFinal1 = row.getCell(26).getStringCellValue().toUpperCase();
                    String semiFinal2 = row.getCell(27).getStringCellValue().toUpperCase();
                    String semiFinal3 = row.getCell(28).getStringCellValue().toUpperCase();
                    String semiFinal4 = row.getCell(29).getStringCellValue().toUpperCase();
                    String thirdPlace = row.getCell(30).getStringCellValue().toUpperCase();
                    String final1 = row.getCell(31).getStringCellValue().toUpperCase();
                    String final2 = row.getCell(32).getStringCellValue().toUpperCase();
                    String winner = row.getCell(33).getStringCellValue().toUpperCase();
                    Double totalGoalsFirstRound = row.getCell(34).getNumericCellValue();
                    Double totalGoalsSecondRound = row.getCell(35).getNumericCellValue();
                    Double totalGoalsQuarterFinal = row.getCell(36).getNumericCellValue();
                    Double tieBreaker = row.getCell(37).getNumericCellValue();

                    points += getGroupPoints(winnerA, "URUGUAY", "RUSSIA");
                    points += getGroupPoints(winnerC, "FRANCE", "DENMARK");
                    points += getGroupPoints(winnerE, "BRAZIL", "SWITZERLAND");
                    points += getGroupPoints(winnerG, "BELGIUM", "ENGLAND");
                    points += getGroupPoints(winnerB, "SPAIN", "PORTUGAL");
                    points += getGroupPoints(winnerD, "CROATIA", "ARGENTINA");
                    points += getGroupPoints(winnerF, "SWEDEN", "MEXICO");
                    points += getGroupPoints(winnerH, "COLOMBIA", "JAPAN");

                    points += getGroupPoints(runnerUpB, "PORTUGAL", "SPAIN");
                    points += getGroupPoints(runnerUpD, "ARGENTINA", "CROATIA");
                    points += getGroupPoints(runnerUpF, "MEXICO", "SWEDEN");
                    points += getGroupPoints(runnerUpH, "JAPAN", "COLOMBIA");
                    points += getGroupPoints(runnerUpA, "RUSSIA", "URUGUAY");
                    points += getGroupPoints(runnerUpC, "DENMARK", "FRANCE");
                    points += getGroupPoints(runnerUpE, "SWITZERLAND", "BRAZIL");
                    points += getGroupPoints(runnerUpG, "ENGLAND", "BELGIUM");

//                    points += getQuarterFinalistsPoints(quarterFinal1, quarterFinal2, quarterFinal3, quarterFinal4, quarterFinal5, quarterFinal6, quarterFinal7, quarterFinal8);
//                    points += getSemiFinalistsPoints(semiFinal1, semiFinal2, semiFinal3, semiFinal4);
//                    points += getFinalistsPoints(final1, final2);
//
//                    if(thirdPlace.equals("")) points += 35;
//                    if(winner.equals("")) points += 40;

                    points += getGoalsPoints(totalGoalsFirstRound, 122.0);
//                    points += getGoalsPoints(totalGoalsSecondRound, 0.0);
//                    points += getGoalsPoints(totalGoalsQuarterFinal, 0.0);

                    Row newRow = results.createRow(rowNum);
                    Cell resultRef = newRow.createCell(0);
                    Cell resultName = newRow.createCell(1);
                    Cell totalPoints = newRow.createCell(2);

                    resultRef.setCellValue(ref);
                    resultName.setCellValue(name);
                    totalPoints.setCellValue(points);


                    rowNum++;
                }
            }

            excelFile.close();
            FileOutputStream output = new FileOutputStream(new File("/Users/ianellis/Downloads/play-java-jpa-example-2.5.x/conf/Ian_Test_World_Cup_2018.xlsx"));
            workbook.write(output);
            output.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static Integer getGroupPoints(String selection, String result, String alternative) {
        Integer points = 0;
        if(selection.equals(result)) {points += 8;}
        else if(selection.equals(alternative)) {points += 2;}

        return points;
    }

    private static Integer getQuarterFinalistsPoints(String... quarterFinalists) {
        Integer points = 0;
        List<String> results = Arrays.asList("", "", "", "", "", "", "", "");

        for(String quarterFinalist : quarterFinalists){
            if(results.contains(quarterFinalist)) points += 12;
        }

        return points;
    }

    private static Integer getSemiFinalistsPoints(String... semiFinalists) {
        Integer points = 0;
        List<String> results = Arrays.asList("", "", "", "");

        for(String semiFinalist : semiFinalists){
            if(results.contains(semiFinalist)) points += 20;
        }

        return points;
    }

    private static Integer getFinalistsPoints(String... finalists) {
        Integer points = 0;
        List<String> results = Arrays.asList("", "");

        for(String semiFinalist : finalists){
            if(results.contains(semiFinalist)) points += 30;
        }

        return points;
    }

    private static Integer getGoalsPoints(Double selection, Double result) {
        Integer points = 0;

        if(selection.equals(result)) {points += 20;}
        else if(selection >= result -3 && selection <= result +3) {points += 12;}
        else if(selection >= result -5 && selection <= result +5) {points += 6;}

        return points;
    }
}

//if(winnerA.equals("")) {points += 8;}
//        else if(winnerA.equals("")) {points += 2;}
//
//        if(winnerC.equals("")) {points += 8;}
//        else if(winnerC.equals("")) {points += 2;}
//
//        if(winnerE.equals("")) {points += 8;}
//        else if(winnerE.equals("")) {points += 2;}
//
//        if(winnerG.equals("")) {points += 8;}
//        else if(winnerG.equals("")) {points += 2;}
//
//        if(winnerB.equals("")) {points += 8;}
//        else if(winnerB.equals("")) {points += 2;}
//
//        if(winnerD.equals("")) {points += 8;}
//        else if(winnerD.equals("")) {points += 2;}
//
//        if(winnerF.equals("")) {points += 8;}
//        else if(winnerF.equals("")) {points += 2;}
//
//        if(winnerH.equals("")) {points += 8;}
//        else if(winnerH.equals("")) {points += 2;}
