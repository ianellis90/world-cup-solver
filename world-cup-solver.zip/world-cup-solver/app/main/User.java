package main;

public class User {
    private String ref;
    private String name;
    private Integer points;

    public User(String ref, String name, Integer points) {
        this.ref = ref;
        this.name = name;
        this.points = points;
    }

    public String getRef() {

        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }
}
